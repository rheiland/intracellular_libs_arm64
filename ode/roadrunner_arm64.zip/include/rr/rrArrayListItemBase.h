#ifndef rrArrayListItemBaseH
#define rrArrayListItemBaseH
//---------------------------------------------------------------------------
#include "rrc_exporter.h"

namespace rrc
{

/**
 * @internal
 * @deprecated
 * a proprietaty collection class that is massivly deprecated.
 */
class C_DECL_SPEC ArrayListItemBase
{
    public:
        virtual ~ArrayListItemBase();
};


}
#endif
